# Function Declaration
def supply_log():
    # try block to ensure log file presence
    try:
        with open('sshd.log','r',buffering=8192) as file:
            for log in file:
                    yield log
    except FileNotFoundError:
        return "File does not exist"


